//
//  FirebaseManager.swift
//  Guarded
//
//  Created by Rodrigo Hilkner on 26/10/17.
//  Copyright © 2017 Rodrigo Hilkner. All rights reserved.
//

import Foundation
import FirebaseDatabase
import CoreLocation

class DatabaseManager {
    
    static var ref: DatabaseReference = Database.database().reference()
    
    //TODO: get completionhandler from adding stuff in database to check if stuff was successfully included or not
    
    ///Adds user object to database
    static func addUser(user: User, completionHandler: @escaping (Error?) -> Void) {
        
        ref.child("users").child(user.id).child("name").setValue(user.name)
        ref.child("users").child(user.id).child("email").setValue(user.email)
    }
    
    ///Copies user's parameters (name, email) to his object in database
    static func updateUser(user: User, completionHandler: @escaping (Error?) -> Void) {
    
        ref.child("users/\(user.id)/name").setValue(user.name)
        ref.child("users/\(user.id)/email").setValue(user.email)
    }
    
    ///Adds protector to user's protectors list and also adds user as protector's protected list
    static func addProtector(protected: User, protector: User, completionHandler: @escaping (Error?) -> Void) {
        
        ref.child("users").child(protected.id).child("protectors").child(protector.id).setValue(true)
        ref.child("users").child(protector.id).child("protected").child(protected.id).setValue(true)
    }
    
    ///Copies user's parameters (name, email) to his object in database
//    static func updateUser(user: User, completionHandler: @escaping (Error?) -> Void) {
//
//        //TODO: is setting value true good enough?
//        ref.child("users/\(protected.id)/protectors/\(protector.id)").setValue(true)
//        ref.child("users/\(protector.id)/protected/\(protected.id)").setValue(true)
//    }
    
    ///Removes protector to user's protectors list and also removes user as protector's protected list
    static func removeProtector(protected: User, protector: User, completionHandler: @escaping (Error?) -> Void) {
        
        //TODO: how to make both removes atomic?
        
        ref.child("users").child(protected.id).child("protectors").child(protector.id).removeValue {
            (error, _) in
            guard error == nil else {
                print("Error on removing protector from database.")
                //TODO: create error "Error on removing protector from database."
                completionHandler(error)
                return
            }
            
            ref.child("users").child(protector.id).child("protected").child(protected.id).removeValue {
                (error, _) in
                guard error == nil else {
                    print("Error on removing protected from database.")
                    //TODO: create error "Error on removing protected from database."
                    completionHandler(error)
                    return
                }
                
                completionHandler(nil)
            }
        }
        
    }
    
    ///Adds place to user's places list
    static func addPlace(user: User, place: Place, completionHandler: @escaping (Error?) -> Void) {
        ref.child("users").child(user.id).child("places").child(place.name).child("address").setValue(place.address)
        ref.child("users").child(user.id).child("places").child(place.name).child("coordinates").child("latitude").setValue(place.coordinate.latitude)
        ref.child("users").child(user.id).child("places").child(place.name).child("coordinates").child("longitude").setValue(place.coordinate.longitude)
    }
    
    ///Removes place from user's places list
    static func removePlace(user: User, place: Place, completionHandler: @escaping (Error?) -> Void) {
        ref.child("users").child(user.id).child("places").child(place.name).removeValue {
            (error, _) in
            guard error == nil else {
                print("Error on removing place from database.")
                //TODO: create error "Error on removing place from database."
                completionHandler(error)
                return
            }
            
            completionHandler(nil)
        }
    }
    
    ///Builds main user object from users' database information
    static func fetchMainUser(by userID: String, completionHandler: @escaping (MainUser?, Error?) -> Void) {
        ref.child("users").child(userID).observe(.value, with: {
            (snapshot) in
            
            let userName = snapshot.childSnapshot(forPath: "name").value! as! String
            let userEmail = snapshot.childSnapshot(forPath: "email").value! as! String
            let userPhoneNumber = snapshot.childSnapshot(forPath: "phoneNumber").value! as! String
            
            let mainUser = MainUser(id: userID, name: userName, email: userEmail, phoneNumber: userPhoneNumber)
            
            
            let latitude = snapshot.childSnapshot(forPath: "lastLocation/latitude").value! as! CLLocationDegrees
            let longitude = snapshot.childSnapshot(forPath: "lastLocation/longitude").value! as! CLLocationDegrees
            
            mainUser.lastLocation = Coordinate(latitude: latitude, longitude: longitude)
            
            //TODO: fetch places, protectors, protected
            
            completionHandler(mainUser, nil)
            
        }, withCancel: { (error) in
            
            print(error.localizedDescription)
            
        })
    }
    
    ///Builds protector object from users' database information
    static func fetchProtector(by userID: String, completionHandler: @escaping (Protector?, Error?) -> Void) {
        
    }
    
    ///Builds protected object from users' database information
    static func fetchProtected(by userID: String, completionHandler: @escaping (Protected?, Error?) -> Void) {
        
    }
    
    /**********************************************
     * TODO: organizar tudo
     * aqui debaixo (urgente)
     **********************************************/
    
    
    /// Change the latitude and longitude values of current location
    static func updateLastLocation(user: User, currentLocation: Coordinate) {
        ref.child(user.id).child("lastLocation").child("latitude").setValue(currentLocation.latitude)
        ref.child(user.id).child("lastLocation").child("longitude").setValue(currentLocation.longitude)
    }
    
    
    /// Return user's current (or last) location
    static func getLastLocation(user: User, completionHandler: @escaping (Coordinate?) -> Void) {
        
        ref.child(user.id).child("lastLocation").observe(.value, with: { (snapshot) in
            
            let latitude = snapshot.childSnapshot(forPath: "latitude").value! as! CLLocationDegrees
            let longitude = snapshot.childSnapshot(forPath: "longitude").value! as! CLLocationDegrees
            
            let userLocation = Coordinate(latitude: latitude, longitude: longitude)
            completionHandler(userLocation)
            
            
        }, withCancel: { (error) in
            
            print(error.localizedDescription)
            
        })
        
        
    }
    
    /// If this locationName doesn`t exist, add new local to myLocal list
    /// if the locationName already exists, update its values
    static func addPlace(user: User, locationName: String, myLocation: Coordinate){
        ref.child(user.id).child("Places").child(locationName).child("latitude").setValue(myLocation.latitude)
        ref.child(user.id).child("Places").child(locationName).child("longitude").setValue(myLocation.longitude)
        
    }
    
    /// devolve um dos mues locais
    static func getPlaces(user: User, locationName: String, completionHandler: @escaping (Coordinate?) -> Void) {
        
        ref.child(user.id).child("Places").child(locationName).observe(.value, with: { (snapshot) in
            
            let latitude = snapshot.childSnapshot(forPath: "latitude").value! as! CLLocationDegrees
            let longitude = snapshot.childSnapshot(forPath: "longitude").value! as! CLLocationDegrees
            
            let userLocation = Coordinate(latitude: latitude, longitude: longitude)
            completionHandler(userLocation)
            
        }, withCancel: { (error) in
            
            print(error.localizedDescription)
            
        })
    }
    
    /// Delete the local with name == locationName
    static func deleteMeusLocais(user: User, locationName: String){
        ref.child(user.id).child("Places").child(locationName).child("latitude").setValue(nil)
        ref.child(user.id).child("Places").child(locationName).child("longitude").setValue(nil)
        
    }
    
}
