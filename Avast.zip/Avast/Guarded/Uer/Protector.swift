//
//  Protectors.swift
//  
//
//  Created by Rodrigo Hilkner on 26/10/17.
//

import Foundation

class Protector: User {
    
}
