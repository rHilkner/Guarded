////
////  FirebaseServices.swift
////  Guarded
////
////  Created by Andressa Aquino on 20/10/17.
////  Copyright © 2017 Rodrigo Hilkner. All rights reserved.
////
//
//import UIKit
//import CoreLocation
//import FirebaseDatabase
//
//protocol receiveFirebaseDataProtocol {
//    func receiveCurrentLocation (location: CLLocationCoordinate2D)
//    func receiveMeusLocais (location: CLLocationCoordinate2D, name: String)
//}
//
//class FirebaseServices {
//
//    var ref: DatabaseReference?
//    var delegate: receiveFirebaseDataProtocol!
//
//    init() {
//        ref = Database.database().reference()
//    }
//
//    /// Change the latitude and longitude values of current location
//    func updateLastLocation(user: User, currentLocation: Coordinate) {
//        ref?.child(user.id).child("lastLocation").child("latitude").setValue(currentLocation.latitude)
//        ref?.child(user.id).child("lastLocation").child("longitude").setValue(currentLocation.longitude)
//    }
//
//
//    /// Return user's current (or last) location
//    func getLastLocation(user: User) {
//
//        ref?.child(user.id).child("lastLocation").observe(.value, with: { (snapshot) in
//
//            let latitude = snapshot.childSnapshot(forPath: "latitude").value! as! Double
//            let longitude = snapshot.childSnapshot(forPath: "longitude").value! as! Double
//
//            let userLocation = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
//            self.delegate.receiveCurrentLocation(location: userLocation)
//
//
//        }, withCancel: { (error) in
//
//            print(error.localizedDescription)
//
//        })
//
//
//    }
//
//    /// If this locationName doesn`t exist, add new local to myLocal list
//    /// if the locationName already exists, update its values
//    func addPlace(user: User, locationName: String, myLocation: Coordinate){
//        ref?.child(user.id).child("Places").child(locationName).child("latitude").setValue(myLocation.latitude)
//        ref?.child(user.id).child("Places").child(locationName).child("longitude").setValue(myLocation.longitude)
//
//    }
//
//    /// devolve um dos mues locais
//    func getPlaces(user: User, locationName: String){
//
//        ref?.child(user.id).child("Places").child(locationName).observe(.value, with: { (snapshot) in
//
//            let latitude = snapshot.childSnapshot(forPath: "latitude").value! as! Double
//            let longitude = snapshot.childSnapshot(forPath: "longitude").value! as! Double
//
//            let userLocation = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
//            self.delegate.receiveCurrentLocation(location: userLocation)
//
//        }, withCancel: { (error) in
//
//            print(error.localizedDescription)
//
//        })
//    }
//
//    /// Delete the local with name == locationName
//    func deleteMeusLocais (user: User, locationName: String){
//        ref?.child(user.id).child("Places").child(locationName).child("latitude").setValue(nil)
//        ref?.child(user.id).child("Places").child(locationName).child("longitude").setValue(nil)
//
//    }
//
//
//}

