//
//  LocationServices.swift
//  Guarded
//
//  Created by Rodrigo Hilkner on 09/10/17.
//  Copyright © 2017 Rodrigo Hilkner. All rights reserved.
//

import Foundation
import CoreLocation


protocol LocationUpdateProtocol {
    func displayCurrentLocation(myLocation: Coordinate)
    func displayOtherLocation(someLocation: Coordinate)
    
}

class LocationServices: NSObject, LocationServicesProtocol, CLLocationManagerDelegate {

    let manager = CLLocationManager()
    let geocoder = CLGeocoder()
    var location: CLLocation?
    var delegate: LocationUpdateProtocol!

    override init() {
        super.init()

        manager.delegate = self

        /// get the best accuracy
        /// to do: check if affects the app performance
        manager.desiredAccuracy = kCLLocationAccuracyBest

        /// test the authorization status, so it doesn't asks permission more than one time
        switch CLLocationManager.authorizationStatus() {
            case .notDetermined:
                // Request when-in-use authorization initially
                manager.requestWhenInUseAuthorization()
                break

            case .restricted, .denied:
                // Disable location features
                print("Error: permission denied or restricted")
                manager.stopUpdatingLocation()
                break

            case .authorizedWhenInUse, .authorizedAlways:
                // Enable location features
                manager.startUpdatingLocation()
                break

        }

    }

    /// this function is called every time the user location is updated
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {

        /// locations is an array with all the locations of the user
        /// locations[0] is the most recent location
        location = locations[0]

        /// create location point
        let userLocation = Coordinate(latitude: location!.coordinate.latitude, longitude: location!.coordinate.longitude)

		AppSettings.mainUser!.lastLocation = userLocation

        /// display the location every time it`s updated
        self.delegate.displayCurrentLocation(myLocation: userLocation)
        
    }

    /// handle authorization status changes
    private func locationManager(manager: CLLocationManager,
                                 didChangeAuthorizationStatus status: CLAuthorizationStatus)
    {
        if status == .authorizedAlways || status == .authorizedWhenInUse {
            manager.startUpdatingLocation()
        }
        else if status == .denied || status == .restricted{
            manager.stopUpdatingLocation()
        }
    }

    /// Receive address and display its location
    func addressToLocation(address: String) {

        let address: String = "Rua Roxo Moreira, 600, Campinas, São Paulo, Brasil"

        geocoder.geocodeAddressString(address) {
            (placemarks, error) in
            
            guard (error == nil) else {
                print("Error", error ?? "")
                return
            }
            
            if let placemark = placemarks?.first {
                let latitude = placemark.location!.coordinate.latitude
                let longitude = placemark.location!.coordinate.longitude
                
                let coordinates = Coordinate(latitude: latitude, longitude: longitude)
                print("Lat: \(coordinates.latitude) -- Long: \(coordinates.longitude)")

                //let annotation = MKPlacemark(placemark: placemark)
                //self.map.addAnnotation(annotation)
                self.delegate.displayOtherLocation(someLocation: coordinates)

            }
        }
    }

    
}
